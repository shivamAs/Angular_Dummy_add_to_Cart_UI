import { Component } from "@angular/core";

@Component({
  selector: "jumbotron-area",
  templateUrl: "./jumbotron.component.html"
})
export class JumbotronComponent {}
