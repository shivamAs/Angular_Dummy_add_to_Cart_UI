import { environment } from "../../environments/environment";

export const baseUrl = "https://www.mocky.io/v2";
export const productsUrl = baseUrl + "/5eda4003330000740079ea60";
